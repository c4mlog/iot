package bk.ltuddd.iotapp.data.model;

import java.util.List;

public class RulesDevice {

    private List<RulesDetailDevice> rulesDetailDeviceList;

}
