package bk.ltuddd.iotapp.feature.timer.viewmodel;

import bk.ltuddd.iotapp.core.base.BaseViewModel;

public class TimerViewModel extends BaseViewModel {
}
