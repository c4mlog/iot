package bk.ltuddd.iotapp.data.network;

public interface ApplicationServices {


}
