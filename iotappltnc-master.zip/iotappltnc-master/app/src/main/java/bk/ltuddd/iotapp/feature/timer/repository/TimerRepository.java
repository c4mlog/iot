package bk.ltuddd.iotapp.feature.timer.repository;

public interface TimerRepository {
}
