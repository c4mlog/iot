package bk.ltuddd.iotapp.feature.countdown.repository;

public interface CountDownRepository {
}
